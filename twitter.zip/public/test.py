def test(input1):
    return len(set([date.split("-")[-1] for date in input1]))

print(test(["2-2-1555", "3-4-1555", "5-6-1556"]))